
import React,{useState,useEffect} from 'react'
import {fetchDailyData } from '../../api'
import {Line,Bar} from 'react-chartjs-2'
import ReactHTMLParser from 'react-html-parser'
import styles from './Charts.module.css'
const Charts=({data:{confirmed,recovered,deaths},state})=>{
    // const [dailyData,setDailyData]=useState({});
    // useEffect(()=>
    // {
    //         const fetchAPI=async()=>
    //         {
    //             setDailyData(await fetchDailyData())
    //         }
    //         fetchAPI();

    // },[]);
    // const lineChart=(
    //     dailyData.length?
    //     <Line 
    //         data={
    //             {
    //                 labels:dailyData.map(({date})=>date),
    //                 datasets:[{
    //                     data:dailyData.map(({confirmed})=>confirmed),
    //                     label:'Infetced',
    //                     borderColor:'#3333ff',
    //                     fill:true   
    //                 },
    //                 {
    //                     data:dailyData.map(({deaths})=>deaths),
    //                     label:'Deaths',
    //                     borderColor:'red',
    //                     backgroundColor:'rgba(255,0,0,0.5)',
    //                     fill:true 
    //                 }]
    //             }
    //         }
    //     />:null
    // );
    console.log(confirmed)
    let barChart=(
        confirmed?
        <Bar
            data={
                {
                    labels:['Infetced','Recovered','Deaths'],
                    datasets:[
                        {
                            label:'People',
                            backgroundColor:['blue','green','red'],
                            data:[confirmed,recovered,deaths]
                        }
                    ]
                }
            }
            options={
                {
                    legend:{display:false},
                    title:{display:true,text:state?`State is ${state}`:`India`,fontColor:'rgba(0,0,255,1)',fontSize:'22'}
                }
            }
        />:null
    );
    return(<div className={styles.container}>
        {barChart}
        </div>)
}
export default Charts
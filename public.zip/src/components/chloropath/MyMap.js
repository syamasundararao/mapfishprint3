import React, { useState,useEffect } from 'react';
import { ComposableMap, Geographies, Geography ,Sphere,
  Graticule} from 'react-simple-maps';
import { scaleQuantile } from 'd3-scale';
import ReactTooltip from 'react-tooltip';
import { Card, CardContent, Typography, Grid } from '@material-ui/core';
import LinearGradient from './LinearGradient.js';
import cx from 'classnames'
import styles from './MyMap.module.css'
import {fetchStateWideData}  from '../../api'
import ReactHTMLParser from 'react-html-parser'
const INDIA_TOPO_JSON = require('./india.topo.json');

const PROJECTION_CONFIG = {
  scale: 1000,
  center: [78.9629, 22.5937],
  rotation: [-11, 0, 0], // always in [East Latitude, North Longitude]
};
function formatNumber(num) {
  return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
}
// Red Variants
const COLOR_RANGE = [
  '#ffedea',
  '#ffcec5',
  '#ffad9f',
  '#ff8a75',
  '#ff5533',
  '#e2492d',
  '#be3d26',
  '#9a311f',
  '#782618'
];

const DEFAULT_COLOR = '#EEE';


const geographyStyle = {
  default: {
    outline: 'none'
  },
  hover: {
    fill: '#ccc',
    transition: 'all 250ms',
    outline: 'none'
  },
  pressed: {
    outline: 'none'
  }
};



function MyMap({handleStateChange}) {
  const [tooltipContent, setTooltipContent] = useState('');
  const [data, setData] = useState([]);
   useEffect(()=>
    {
            const fetchAPI=async()=>
            {
                setData(await fetchStateWideData())
            }
            fetchAPI();

    },[]);
   
data.forEach(function(a) {
  a.loc = a.loc.toString().replace('Telengana','Telangana');
  a.loc = a.loc.toString().replace('Jammu and Kashmir','Jammu & Kashmir');
 //a.loc = a.loc.toString().replace('Jammu and Kashmir','Jammu & Kashmir');
});
data.forEach(function(a) {
  
});

  const gradientData = {
    fromColor: COLOR_RANGE[0],
    toColor: COLOR_RANGE[COLOR_RANGE.length - 1],
    min: 0,
  

    max: data.reduce((max, item) => (item.confirmedCasesIndian > max ? item.confirmedCasesIndian : max), 0)
  };

  const colorScale = scaleQuantile()
    .domain(data.map(d => d.confirmedCasesIndian))
    .range(COLOR_RANGE);

  const onMouseEnter = (geo, current = { value: 'NA' }) => {
    
    //  
    return () => {
      setTooltipContent(ReactHTMLParser(`${geo.properties.name} <br/> Infected <b>${formatNumber(current.confirmedCasesIndian)}</b> <br/>
       Recovered <b>${formatNumber(current.discharged)}</b> <br/> Deaths: <b>${formatNumber(current.deaths)}<b> `));
    };
  };

  const onMouseLeave = () => {
    setTooltipContent('');
  };

  return (
    <React.Fragment>
    <Grid container spacing={3} justify="center">
      <Grid item xs={12} md={6} component={Card} className={cx(styles.card)}>
      <ReactTooltip>{tooltipContent}</ReactTooltip>
        <ComposableMap
          projectionConfig={PROJECTION_CONFIG}
          projection="geoMercator"
          data-tip=""
         width={700}
         height={500}

        >
           <Sphere stroke="#E4E5E6" strokeWidth={2} />
      <Graticule stroke="#E4E5E6" strokeWidth={2} step={[10,10]} />

          <Geographies geography={INDIA_TOPO_JSON} >
            {({ geographies }) =>
              geographies.map(geo => {
               
                const current = data.find(s => s.loc === geo.properties.name);
           
                return (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    fill={current ? colorScale(current.confirmedCasesIndian) : DEFAULT_COLOR}
                    style={geographyStyle}
                    onMouseEnter={onMouseEnter(geo, current)}
                    onMouseLeave={onMouseLeave}
                   
                  />
                );
              })
            }
             

          </Geographies>
        </ComposableMap>
        <LinearGradient data={gradientData} />
      
    </Grid>
    </Grid>
    </React.Fragment>
  );
}

export default MyMap;
import React,{useState,useEffect} from 'react'
import {FetchStates} from '../../api'
import {NativeSelect,FormControl} from '@material-ui/core'
import styles from './StatePicker.module.css'
 const StatePicker=({handleStateChange})=>{
    const [states,setFetchStates]=useState([])
    useEffect(()=>{
        const fetchStates=async()=>{
                setFetchStates(await FetchStates())
        } 
    fetchStates();
    },[setFetchStates])
    return(<div>
        <FormControl className={styles.formcontrol}>
            <NativeSelect default='' onChange={(e)=>handleStateChange(e.target.value)}>
                <option value=''>India</option>
                {states.map((state,i)=><option key={i} value={state}>{state}</option>)}
            </NativeSelect>
        </FormControl>
    </div>)
}
export default StatePicker
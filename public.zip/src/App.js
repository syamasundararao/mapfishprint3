import React from 'react'
import {Cards,Charts,StatePicker} from './components'
import {fetchData,FetchStateDetails} from './api'
import {fetchIndiaData} from './api'
import coronoImage from './images/covid19_2.png'
import MyMap from './components/chloropath/MyMap'
class App extends React.Component
{
    state={
        data:[],
        indiadata:[],
       
        state:'',
    }
    async componentDidMount()
    {
        let indiadata=await fetchIndiaData()
        console.log(indiadata)
        this.setState({indiadata:indiadata})
    }
    handleStateChange=async(state)=>{
        console.log(state)
        let data=await fetchIndiaData(state)
        console.log(data)
        this.setState({indiadata:data,state:state})
    }
    render()
    {
        const {data,state,indiadata}= this.state
    return(
        <div className="container">
            <img className="image" src={coronoImage}/>
            <Cards data={indiadata} />
            <StatePicker handleStateChange={this.handleStateChange}/>
            <MyMap />
            
           
            <Charts data={indiadata} state={state}/> 
        </div>
    )
    }
}
export default App;
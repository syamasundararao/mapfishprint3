import axios from 'axios'
const url='https://covid-19.mathdro.id/api'
const indiaurl='https://api.rootnet.in/covid19-in/stats/latest'
export const fetchData=async(country)=>
{
let changeurl=url;
if(country)
{
    changeurl=`${url}/countries/${country}`
}
try{
    const {data:{confirmed,recovered,deaths,lastUpdate}}=await axios.get(changeurl);
    if(confirmed)
    return {
        confirmed,
        recovered,
        deaths,
        lastUpdate
    }
    else
        alert('Error in retrieving data')
 
}catch(error){

}
}

export const fetchDailyData=async()=>{
    try
    {
     const {data}=await axios.get(`${url}/daily`);
    const modifieddata=data.map((dailyData)=>({
        confirmed:dailyData.confirmed.total,
        deaths:dailyData.deaths.total,
        date:dailyData.reportDate
    }));
    return(modifieddata)
    }catch(error)
    {
        }

}
export const FetchCountries=async()=>{
    try
    {
        const {data:{countries}} =await axios.get(`${url}/countries`)
        return(countries.map((country)=>country.name))

    }catch(error){
        
    }
}

export const FetchStates=async()=>
{
    try
    {
        const response=await axios.get(indiaurl)
        console.log(response.data.data.regional)
        return(response.data.data.regional.map((state)=>state.loc))
       
    }
    catch(errror){

    }
}

export const fetchIndiaData=async(state)=>
{

try{
    if(!state){
    const response=await axios.get(indiaurl);
    const {total,discharged,deaths}=response.data.data.summary
  //  console.log(response.data)
    const lastUpdate=response.data.lastOriginUpdate
    console.log(lastUpdate)
    return({
        confirmed:total,
        recovered:discharged,
        deaths:deaths,
        lastUpdate:lastUpdate
    })
    }
    else
    {
        const response=await axios.get(indiaurl)
        let reg=response.data.data.regional
        let result =reg.find((reg)=>reg.loc===state)
        const {confirmedCasesIndian,discharged,deaths}=result
        const lastUpdate=response.data.lastOriginUpdate
        console.log(lastUpdate)
        return({
            confirmed:confirmedCasesIndian,
            recovered:discharged,
            deaths:deaths,
            lastUpdate:lastUpdate
        })

    }
}catch(error){

}
}

export const fetchStateWideData=async()=>
{
    try
    {
        const response=await axios.get(indiaurl)
        let reg=response.data.data.regional
        return(reg)

    }catch(error)
    {

    }
}


This example uses a datasource processor, whereas each entry of the datasource contains a
`title` attribute and a table. For the template `A4 portrait` the default template for the
table is used. Template `A4 landscape` also uses the default table template, but a custom
`reportWidth` is used.

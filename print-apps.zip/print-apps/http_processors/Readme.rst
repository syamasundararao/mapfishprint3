This example demonstrates how to configure and control http requests that are made in the system.

For example it shows how to restrict the URLs that are allowed and control which headers are sent with each request.

The file of interest is the config.yaml file.
This example combines several tables, a map and a legend into a single datasource using the MergeDataSourceProcessor (!mergeDataSources)
and displays them in the main report's detail section.

By doing this the client has options to not print a map or legend or any number of tables and the output will be consistent.
